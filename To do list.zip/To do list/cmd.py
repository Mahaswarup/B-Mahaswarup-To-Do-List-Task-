# Command-line based To-Do List application

class ToDoList:
    def __init__(self):
        self.tasks = []

    def add_task(self, task):
        self.tasks.append({"task": task, "completed": False})
        print(f"Added task: {task}")

    def update_task(self, index, new_task):
        if 0 <= index < len(self.tasks):
            self.tasks[index]["task"] = new_task
            print(f"Updated task {index + 1} to: {new_task}")
        else:
            print("Invalid task index")

    def complete_task(self, index):
        if 0 <= index < len(self.tasks):
            self.tasks[index]["completed"] = True
            print(f"Completed task {index + 1}")
        else:
            print("Invalid task index")

    def show_tasks(self):
        if not self.tasks:
            print("No tasks in the list")
        for i, task in enumerate(self.tasks):
            status = "Done" if task["completed"] else "Not Done"
            print(f"{i + 1}. {task['task']} - {status}")

def main():
    todo_list = ToDoList()
    while True:
        print("\nTo-Do List Menu:")
        print("1. Add Task")
        print("2. Update Task")
        print("3. Complete Task")
        print("4. Show Tasks")
        print("5. Exit")
        choice = input("Enter your choice: ")
        
        if choice == '1':
            task = input("Enter task: ")
            todo_list.add_task(task)
        elif choice == '2':
            index = int(input("Enter task number to update: ")) - 1
            new_task = input("Enter new task: ")
            todo_list.update_task(index, new_task)
        elif choice == '3':
            index = int(input("Enter task number to complete: ")) - 1
            todo_list.complete_task(index)
        elif choice == '4':
            todo_list.show_tasks()
        elif choice == '5':
            print("Exiting...")
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
